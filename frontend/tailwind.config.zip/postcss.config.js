/* eslint-disable linebreak-style */
/* eslint-disable indent */
export const plugins = {
    tailwindcss: {}, // Load Tailwind CSS
    autoprefixer: {}, // Load Autoprefixer
    'postcss-import': {},
};
